import sqlite3

from app.inventory import node_by_id


def test_node_by_id():
    db = sqlite3.connect(":memory:")
    db.execute("CREATE TABLE nodes (id INTEGER, name TEXT, mgmt_ip TEXT, site TEXT)")
    db.execute("INSERT INTO nodes VALUES (1, 'gnb-01', '10.0.0.1', 'kista')")
    assert node_by_id(db, 1) == ("gnb-01", "10.0.0.1", "kista")


def test_tmp_db(tmp_path=None):
    path = "/tmp/netcfg-test.db"
    db = sqlite3.connect(path)
    assert db is not None
