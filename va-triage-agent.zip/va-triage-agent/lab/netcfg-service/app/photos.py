"""Thumbnails for site-survey photos uploaded by field engineers."""

import io

from PIL import Image, ImageOps

ALLOWED_FORMATS = ["JPEG", "PNG", "WEBP"]


def make_thumbnail(upload: bytes, size: int = 256) -> bytes:
    with Image.open(io.BytesIO(upload), formats=ALLOWED_FORMATS) as im:
        im = ImageOps.exif_transpose(im)
        im.thumbnail((size, size))
        out = io.BytesIO()
        im.save(out, format="PNG")
        return out.getvalue()
