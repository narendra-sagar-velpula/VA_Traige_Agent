"""Service settings."""

import os

DEFAULT_ADMIN_USER = "netadmin"
DEFAULT_ADMIN_PASSWORD = "Netcfg@2024!"

# Name of the form field that carries the password on the login page.
PASSWORD_FIELD = "password"

DATABASE_PATH = os.environ.get("NETCFG_DB", "/var/lib/netcfg/inventory.db")
