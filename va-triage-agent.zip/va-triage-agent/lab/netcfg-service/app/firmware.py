"""Firmware manifests from the vendor portal."""

import requests

VENDOR_URL = "https://firmware.vendor.example/api/v2/manifest"


def fetch_manifest(version: str, token: str) -> dict:
    """`version` is chosen by the operator in the upgrade form."""
    resp = requests.get(
        VENDOR_URL,
        params={"version": version},
        headers={"Authorization": f"Bearer {token}"},
        timeout=10,
    )
    resp.raise_for_status()
    return resp.json()
