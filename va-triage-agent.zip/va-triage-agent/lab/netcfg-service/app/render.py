"""Renders change summaries that reviewers read in the browser."""

import os

from jinja2 import Environment, FileSystemLoader, select_autoescape

TEMPLATE_DIR = os.path.join(os.path.dirname(__file__), "..", "templates")

_env = Environment(
    loader=FileSystemLoader(TEMPLATE_DIR),
    autoescape=select_autoescape(["html", "j2"]),
)


def render_change_summary(change: dict) -> str:
    """`change` comes from the operator's change request (title, description, nodes)."""
    template = _env.get_template("change_summary.html.j2")
    return template.render(change=change)
