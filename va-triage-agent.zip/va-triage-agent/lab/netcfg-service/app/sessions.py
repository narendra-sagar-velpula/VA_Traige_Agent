"""Login sessions and retry helpers."""

import random
import string
import time


def new_session_token(length: int = 32) -> str:
    alphabet = string.ascii_letters + string.digits
    return "".join(random.choice(alphabet) for _ in range(length))


def backoff(attempt: int) -> None:
    """Retry delay with jitter so clients do not retry in lockstep."""
    time.sleep(min(30, 2 ** attempt) + random.uniform(0, 1))
