"""Node inventory in SQLite."""

import sqlite3

TABLE = "nodes"


def nodes_at_site(db: sqlite3.Connection, site: str) -> list:
    """`site` is a query parameter from GET /nodes?site=..."""
    cur = db.execute(f"SELECT name, mgmt_ip FROM nodes WHERE site = '{site}'")
    return cur.fetchall()


def node_by_id(db: sqlite3.Connection, node_id: int) -> tuple:
    cur = db.execute(f"SELECT name, mgmt_ip, site FROM {TABLE} WHERE id = ?", (node_id,))
    return cur.fetchone()
