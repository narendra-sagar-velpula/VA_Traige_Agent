"""netcfg-service: configuration helper for network elements (lab target, do not deploy)."""
