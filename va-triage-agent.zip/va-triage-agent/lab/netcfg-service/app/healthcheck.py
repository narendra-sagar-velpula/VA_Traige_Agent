"""Health checks against network elements' management interfaces."""

import requests


def check_node(host: str) -> bool:
    """`host` is the management address entered by the operator."""
    # Many lab nodes use self-signed certificates.
    resp = requests.get(f"https://{host}/health", verify=False, timeout=5)
    return resp.status_code == 200
