"""Node configuration upload and defaults."""

import yaml


def parse_uploaded_config(body: bytes) -> dict:
    """Operators upload node configuration as YAML through POST /configs."""
    config = yaml.load(body, Loader=yaml.FullLoader)
    if not isinstance(config, dict):
        raise ValueError("configuration must be a mapping")
    return config


def load_defaults(path: str) -> dict:
    with open(path, encoding="utf-8") as f:
        return yaml.safe_load(f) or {}
