"""Signs configuration bundles and verifies vendor firmware signatures."""

import os

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

KEY_DIR = os.path.join(os.path.dirname(__file__), "..", "keys")


def sign_bundle(bundle: bytes, private_key_pem: bytes) -> bytes:
    key = serialization.load_pem_private_key(private_key_pem, password=None)
    if not isinstance(key, Ed25519PrivateKey):
        raise TypeError("bundle signing key must be Ed25519")
    return key.sign(bundle)


def verify_firmware(manifest: bytes, signature: bytes) -> None:
    """Vendor public key ships with the service in keys/vendor_p256.pem."""
    with open(os.path.join(KEY_DIR, "vendor_p256.pem"), "rb") as f:
        vendor_key = serialization.load_pem_public_key(f.read())
    vendor_key.verify(signature, manifest, ec.ECDSA(hashes.SHA256()))
