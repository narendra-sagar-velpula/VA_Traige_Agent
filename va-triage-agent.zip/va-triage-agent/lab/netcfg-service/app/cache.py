"""Small cache for rendered summaries."""

import hashlib

_cache: dict = {}


def cache_key(change_id: str, template_version: str) -> str:
    return hashlib.md5(f"{change_id}:{template_version}".encode()).hexdigest()


def get_or_render(change_id: str, template_version: str, render) -> str:
    key = cache_key(change_id, template_version)
    if key not in _cache:
        _cache[key] = render()
    return _cache[key]
