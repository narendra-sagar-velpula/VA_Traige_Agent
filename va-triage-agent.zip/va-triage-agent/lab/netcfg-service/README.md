# netcfg-service (lab target)

A small, deliberately outdated internal service used as the **system under analysis** for
va-triage-agent. It is never run by the pipeline, only scanned and analysed.

What it does: operators upload node configuration (YAML), the service renders change summaries
(Jinja2), fetches firmware manifests from a vendor API (requests), verifies vendor signatures and
signs config bundles (cryptography), makes thumbnails of site-survey photos (Pillow), and runs
diagnostics against network elements.

The dependency pins in `requirements.txt` are old on purpose (the 2024.2 release). `paramiko` is a
leftover from an SSH feature removed in 2024.1 and is no longer imported.

Do not deploy this code.
