"""Collect findings from scanners into one clean, de-duplicated, enriched dataset.

Inputs: an SBOM (matched against OSV advisories), Bandit JSON, and any SARIF file (Semgrep, CodeQL, ...).
Cleaning: strip ANSI and control characters, cap text length, redact secrets before any text can reach a
report or an LLM. De-duplication: the same vulnerability published twice for one package, and the same
SAST issue reported by two tools at one location.
"""

from __future__ import annotations

import json
import math
import re
from collections import Counter
from pathlib import Path

from . import cvss
from .advisories import KEV, AdvisoryDB, normalize
from .models import Finding
from .sbom import read_cyclonedx

ANSI = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]")
CONTROL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
CVE_RE = re.compile(r"\bCVE-\d{4}-\d{4,}\b")
SECRET_ASSIGN = re.compile(
    r"""(?i)\b([A-Za-z_]*(?:pass(?:word|wd)?|secret|token|api_?key|private_?key)[A-Za-z_]*)\s*[:=]\s*(["'])(.+?)\2"""
)
SECRET_PATTERNS = [
    re.compile(r"AKIA[0-9A-Z]{16}"),  # AWS access key id
    re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]+?-----END [A-Z ]*PRIVATE KEY-----"),
    re.compile(r"(?i)\bbearer\s+[a-z0-9._~+/-]{20,}=*"),
    re.compile(r"\bgh[pousr]_[A-Za-z0-9]{36,}\b"),  # GitHub tokens
]
MAX_TEXT = 4000


def clean(text: str | None, limit: int = MAX_TEXT) -> str:
    if not text:
        return ""
    text = CONTROL.sub("", ANSI.sub("", text))
    return text if len(text) <= limit else text[: limit - 15] + " …[truncated]"


def _entropy(s: str) -> float:
    counts = Counter(s)
    return -sum(c / len(s) * math.log2(c / len(s)) for c in counts.values())


def looks_secret(value: str) -> bool:
    """Field names like 'password' or 'api_key' are not secrets; mixed, high-entropy strings are."""
    if re.fullmatch(r"[a-z_]{1,24}", value) or value in ("", "***", "changeme"):
        return False
    classes = sum(bool(re.search(p, value)) for p in (r"[a-z]", r"[A-Z]", r"\d", r"[^A-Za-z0-9]"))
    return len(value) >= 8 and (classes >= 3 or _entropy(value) > 3.5)


def redact(text: str | None) -> str:
    if not text:
        return ""

    def repl(m: re.Match) -> str:
        name, q, value = m.group(1), m.group(2), m.group(3)
        if not looks_secret(value):
            return m.group(0)
        return f"{name} = {q}[REDACTED {len(value)} chars]{q}"

    text = SECRET_ASSIGN.sub(repl, text)
    for p in SECRET_PATTERNS:
        text = p.sub("[REDACTED]", text)
    return text


BOILERPLATE = re.compile(
    r"\b(is an? (Python|HTTP|user-friendly)|is a package designed|is a Python|library for Python)\b", re.I
)


def _title(adv) -> str:
    if adv.summary:
        return clean(adv.summary, 160)
    sentences = [s.strip() for s in re.split(r"(?<=\.)\s+", adv.details) if s.strip()]
    useful = [s for s in sentences if not BOILERPLATE.search(s)]
    return clean((useful or sentences or [adv.id])[0], 160)


def sca_findings(sbom_path: str | Path, db: AdvisoryDB, kev: KEV) -> tuple[str, list[Finding]]:
    app, components = read_cyclonedx(sbom_path)
    out = []
    for c in components:
        for a in db.matching(c.name, c.version):
            ids = [a.id, *a.aliases]
            score = a.cvss_score
            out.append(
                Finding(
                    key=f"sca:{normalize(c.name)}@{c.version}:{a.id}",
                    source="sca",
                    tool="osv-sbom-matcher",
                    rule_id=a.id,
                    aliases=a.aliases,
                    title=_title(a),
                    details=redact(clean(a.details)),
                    package=normalize(c.name),
                    version=c.version,
                    fixed_in=a.fixed_versions(),
                    cwe=a.cwe,
                    severity=cvss.severity(score),
                    cvss_score=score,
                    cvss_vector=a.severity_vector,
                    kev=kev.lookup(ids) is not None,
                )
            )
    return app, out


BANDIT_SEV = {"HIGH": "high", "MEDIUM": "medium", "LOW": "low"}


def bandit_findings(path: str | Path, code_root: str | Path | None = None) -> list[Finding]:
    doc = json.loads(Path(path).read_text())
    version = (doc.get("generated_at") and "bandit") or "bandit"
    out = []
    for r in doc.get("results", []):
        rel = _rel(r["filename"], code_root)
        cwe = r.get("issue_cwe") or {}
        out.append(
            Finding(
                key=f"sast:{r['test_id']}:{rel}:{r['line_number']}",
                source="sast",
                tool=version,
                rule_id=r["test_id"],
                title=clean(f"{r['test_name']}: {r['issue_text']}", 200),
                details=redact(clean(r["issue_text"])),
                file=rel,
                line=r["line_number"],
                snippet=redact(clean(r.get("code"), 1200)),
                cwe=[f"CWE-{cwe['id']}"] if cwe.get("id") else [],
                severity=BANDIT_SEV.get(r.get("issue_severity", ""), "unknown"),
                confidence=(r.get("issue_confidence") or "").lower() or None,
            )
        )
    return out


SARIF_LEVEL = {"error": "high", "warning": "medium", "note": "low", "none": "info"}


def sarif_findings(path: str | Path, code_root: str | Path | None = None) -> list[Finding]:
    doc = json.loads(Path(path).read_text())
    out = []
    for run in doc.get("runs", []):
        tool = run.get("tool", {}).get("driver", {}).get("name", "sarif")
        rules = {r.get("id"): r for r in run.get("tool", {}).get("driver", {}).get("rules", [])}
        for res in run.get("results", []):
            loc = (res.get("locations") or [{}])[0].get("physicalLocation", {})
            rel = _rel(loc.get("artifactLocation", {}).get("uri", "unknown"), code_root)
            line = loc.get("region", {}).get("startLine")
            rule_id = res.get("ruleId") or "unknown"
            props = (rules.get(rule_id) or {}).get("properties", {})
            out.append(
                Finding(
                    key=f"sast:{rule_id}:{rel}:{line}",
                    source="sast",
                    tool=tool,
                    rule_id=rule_id,
                    title=clean(res.get("message", {}).get("text", rule_id), 200),
                    details=redact(clean(res.get("message", {}).get("text"))),
                    file=rel,
                    line=line,
                    snippet=redact(clean(loc.get("region", {}).get("snippet", {}).get("text"), 1200)) or None,
                    cwe=[t.upper().replace("EXTERNAL/CWE/", "") for t in props.get("tags", []) if "cwe" in t.lower()][
                        :3
                    ],
                    severity=SARIF_LEVEL.get(res.get("level", "warning"), "medium"),
                )
            )
    return out


def _rel(filename: str, code_root: str | Path | None) -> str:
    p = Path(filename.removeprefix("file://"))
    if code_root and not p.is_absolute() and (Path(code_root) / p).exists():
        return p.as_posix()
    if code_root:
        try:
            return p.resolve().relative_to(Path(code_root).resolve()).as_posix()
        except ValueError:
            pass
    return p.as_posix().lstrip("./")


def dedupe(findings: list[Finding]) -> tuple[list[Finding], int]:
    """Merge (a) an advisory without its own CVE that only re-publishes another advisory's CVE for the
    same package, and (b) SAST findings at the same location with the same CWE from different tools."""
    merged = 0
    by_alias: dict[tuple[str, str], Finding] = {}
    for f in findings:
        if f.source == "sca":
            for a in [f.rule_id, *f.aliases]:
                by_alias[(f.package or "", a)] = f
    keep: list[Finding] = []
    for f in findings:
        if f.source == "sca" and not any(a.startswith("CVE-") for a in f.aliases):
            target = next(
                (
                    by_alias.get((f.package or "", c))
                    for c in CVE_RE.findall(f.details)
                    if by_alias.get((f.package or "", c)) not in (None, f)
                ),
                None,
            )
            if target is not None:
                target.also_reported_by.append(f.key)
                merged += 1
                continue
        keep.append(f)
    out: list[Finding] = []
    seen: dict[tuple, Finding] = {}
    for f in keep:
        sig = (f.file, f.line, tuple(f.cwe)) if f.source == "sast" and f.cwe else None
        if sig and sig in seen and seen[sig].tool != f.tool:
            seen[sig].also_reported_by.append(f.key)
            merged += 1
            continue
        if sig:
            seen[sig] = f
        out.append(f)
    return out, merged


def collect(
    sbom: str | Path | None,
    bandit: list[str] | None,
    sarif: list[str] | None,
    advisories: str | Path,
    kev_path: str | Path | None,
    code_root: str | Path | None,
) -> dict:
    db, kev = AdvisoryDB(advisories), KEV(kev_path)
    app, findings = "unknown", []
    if sbom:
        app, findings = sca_findings(sbom, db, kev)
    for b in bandit or []:
        findings += bandit_findings(b, code_root)
    for s in sarif or []:
        findings += sarif_findings(s, code_root)
    raw = len(findings)
    findings, merged = dedupe(findings)
    return {"product": app, "raw_findings": raw, "merged": merged, "kev_catalog": kev.version, "findings": findings}
