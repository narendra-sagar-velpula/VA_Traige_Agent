"""Everything an analysis step can look at: findings, code, SBOM, advisories, KEV, deployment files.

The same read-only operations back the MCP tools (for the agent) and the CLI. Paths are confined to the
code root, and code text is secret-redacted before it leaves this module.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

from .advisories import BM25, KEV, AdvisoryDB, normalize
from .models import Finding
from .pipeline import redact
from .reach import CodeIndex
from .sbom import Component, dependents, read_cyclonedx

MAX_LINES = 150


def save_findings(path: str | Path, collected: dict) -> None:
    doc = {k: v for k, v in collected.items() if k != "findings"}
    doc["findings"] = [f.model_dump() for f in collected["findings"]]
    Path(path).write_text(json.dumps(doc, indent=1))


def load_findings(path: str | Path) -> tuple[dict, list[Finding]]:
    doc = json.loads(Path(path).read_text())
    return {k: v for k, v in doc.items() if k != "findings"}, [Finding(**f) for f in doc["findings"]]


@dataclass
class Workspace:
    meta: dict
    findings: dict[str, Finding]
    root: Path
    index: CodeIndex
    components: list[Component]
    db: AdvisoryDB
    kev: KEV
    _bm25: BM25 | None = None

    @classmethod
    def load(
        cls,
        findings: str | Path,
        code_root: str | Path,
        sbom: str | Path,
        advisories: str | Path,
        kev: str | Path | None,
    ) -> Workspace:
        meta, items = load_findings(findings)
        _, comps = read_cyclonedx(sbom)
        root = Path(code_root).resolve()
        return cls(
            meta, {f.key: f for f in items}, root, CodeIndex.build(root), comps, AdvisoryDB(advisories), KEV(kev)
        )

    # -- tool operations ---------------------------------------------------------------------------
    def finding(self, key: str) -> dict:
        f = self.findings.get(key)
        if f is None:
            raise KeyError(f"unknown finding {key!r}")
        return f.model_dump(exclude={"details"})

    def _safe_path(self, rel: str) -> Path:
        p = (self.root / rel).resolve()
        if not p.is_relative_to(self.root) or not p.is_file():
            raise PermissionError(f"{rel!r} is not a file inside the analysed code")
        return p

    def read_code(self, path: str, start_line: int = 1, end_line: int = 60) -> tuple[str, list[int]]:
        p = self._safe_path(path)
        lines = p.read_text(encoding="utf-8", errors="replace").splitlines()
        start = max(1, start_line)
        end = min(len(lines), end_line, start + MAX_LINES - 1)
        body = "\n".join(f"{i:4d}  {lines[i - 1]}" for i in range(start, end + 1))
        rel = p.relative_to(self.root).as_posix()
        return f"{rel} lines {start}-{end} of {len(lines)}\n{redact(body)}", list(range(start, end + 1))

    def find_usages(self, symbol: str) -> list[dict]:
        uses = self.index.find(symbol) or self.index.imported(symbol)
        if not uses:  # fall back to a plain text search (covers templates and strings)
            uses = [
                u
                for rel, lines in self.index.lines.items()
                for i, line in enumerate(lines, 1)
                if symbol in line
                for u in [type("U", (), {"file": rel, "line": i, "text": line.strip()})]
            ]
        return [{"file": u.file, "line": u.line, "code": redact(u.text)} for u in uses[:30]]

    def advisory(self, advisory_id: str) -> dict:
        f = next((x for x in self.findings.values() if x.rule_id == advisory_id or advisory_id in x.aliases), None)
        a = (
            self.db.get(advisory_id)
            if f is None
            else next((x for x in self.db.for_package(f.package or "") if x.id == f.rule_id), None)
        )
        if a is None:
            raise KeyError(f"unknown advisory {advisory_id!r}")
        kev = self.kev.lookup([a.id, *a.aliases])
        return {
            "id": a.id,
            "package": a.package,
            "aliases": a.aliases,
            "summary": a.summary,
            "details": redact(a.details),
            "fixed_in": a.fixed_versions(),
            "cvss": a.cvss_score,
            "cvss_vector": a.severity_vector,
            "cwe": a.cwe,
            "references": a.references,
            "cisa_kev": {"dateAdded": kev["dateAdded"], "requiredAction": kev["requiredAction"]} if kev else None,
        }

    def search_advisories(self, query: str, package: str | None = None, k: int = 5) -> list[dict]:
        if self._bm25 is None:
            self._advs = {a.id: a for a in self.db.all()}
            self._bm25 = BM25([(i, f"{a.package} {a.summary} {a.details}") for i, a in self._advs.items()])
        hits = self._bm25.search(f"{query} {package or ''}", k=k * 3)
        out = []
        for i, score in hits:
            a = self._advs[i]
            if package and normalize(package) != a.package:
                continue
            out.append(
                {"id": i, "package": a.package, "score": round(score, 2), "summary": (a.summary or a.details)[:200]}
            )
        return out[:k]

    def dependency_path(self, package: str) -> dict:
        pkg = normalize(package)
        comp = next((c for c in self.components if normalize(c.name) == pkg), None)
        if comp is None:
            raise KeyError(f"{package!r} is not in the SBOM")
        parents = [p for p in dependents(self.components).get(pkg, []) if p != pkg]
        return {
            "package": pkg,
            "version": comp.version,
            "direct_dependency": comp.direct,
            "pulled_in_by": parents,
            "imported_by_service": [f"{u.file}:{u.line}" for u in self.index.imported(pkg)][:10],
            "parents_imported_by_service": {
                p: [f"{u.file}:{u.line}" for u in self.index.imported(p)][:5] for p in parents
            },
        }

    def deployment_files(self) -> dict[str, str]:
        out = {}
        for p in sorted(self.root.rglob("*")):
            rel = p.relative_to(self.root).as_posix()
            if p.is_file() and (rel.startswith("deploy/") or p.name in ("Dockerfile", "requirements.txt")):
                out[rel] = redact(p.read_text(encoding="utf-8", errors="replace")[:6000])
        return out
