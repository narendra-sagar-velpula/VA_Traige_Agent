"""Data model shared by the pipeline, the triage engines, the reports and the evaluation."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field

Severity = Literal["critical", "high", "medium", "low", "info", "unknown"]
Status = Literal["affected", "not_affected", "needs_review"]
Priority = Literal["P1", "P2", "P3", "P4"]

# OpenVEX "not_affected" justifications
VexJustification = Literal[
    "component_not_present",
    "vulnerable_code_not_present",
    "vulnerable_code_not_in_execute_path",
    "vulnerable_code_cannot_be_controlled_by_adversary",
    "inline_mitigations_already_exist",
]


class Finding(BaseModel):
    key: str  # stable id, e.g. sca:pillow@10.0.0:PYSEC-2023-175 or sast:B602:app/net.py:12
    source: Literal["sca", "sast"]
    tool: str
    rule_id: str  # advisory id or SAST rule id
    aliases: list[str] = Field(default_factory=list)
    title: str
    details: str = ""
    package: str | None = None
    version: str | None = None
    fixed_in: list[str] = Field(default_factory=list)
    file: str | None = None
    line: int | None = None
    snippet: str | None = None
    cwe: list[str] = Field(default_factory=list)
    severity: Severity = "unknown"
    confidence: str | None = None  # SAST tool confidence
    cvss_score: float | None = None
    cvss_vector: str | None = None
    kev: bool = False
    also_reported_by: list[str] = Field(default_factory=list)


class Decision(BaseModel):
    key: str
    status: Status
    priority: Priority
    justification: str
    vex_justification: VexJustification | None = None
    evidence: list[str] = Field(default_factory=list)  # file:line, advisory ids, tool results
    decided_by: Literal["rule", "agent", "human"] = "rule"
    needs_human: bool = False
    guardrail: str | None = None  # set when a guardrail changed the engine's answer
