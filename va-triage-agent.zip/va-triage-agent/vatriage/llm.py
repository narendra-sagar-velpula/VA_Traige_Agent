"""OpenAI-compatible chat client (Groq, OpenAI, Mistral, Ollama, vLLM ...).

VA_LLM_BASE_URL  e.g. https://api.groq.com/openai/v1
VA_LLM_API_KEY
VA_LLM_MODEL     e.g. llama-3.3-70b-versatile
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from typing import Protocol


@dataclass
class ToolCall:
    id: str
    name: str
    arguments: dict


@dataclass
class LLMReply:
    content: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)


class ChatLLM(Protocol):
    def chat(self, messages: list[dict], tools: list[dict] | None = None) -> LLMReply: ...


class OpenAICompatLLM:
    def __init__(self, model: str | None = None, base_url: str | None = None, api_key: str | None = None):
        from openai import OpenAI

        self.model = model or os.environ.get("VA_LLM_MODEL", "llama-3.3-70b-versatile")
        self.client = OpenAI(
            base_url=base_url or os.environ.get("VA_LLM_BASE_URL", "https://api.groq.com/openai/v1"),
            api_key=api_key or os.environ.get("VA_LLM_API_KEY", "missing-key"),
        )

    def chat(self, messages: list[dict], tools: list[dict] | None = None) -> LLMReply:
        kwargs = {"model": self.model, "messages": messages, "temperature": 0}
        if tools:
            kwargs.update(tools=tools, tool_choice="auto")
        msg = self.client.chat.completions.create(**kwargs).choices[0].message
        calls = []
        for tc in msg.tool_calls or []:
            try:
                args = json.loads(tc.function.arguments or "{}")
            except json.JSONDecodeError:
                args = {}
            calls.append(ToolCall(tc.id, tc.function.name, args))
        return LLMReply(msg.content or "", calls)


def assistant_message(reply: LLMReply) -> dict:
    msg: dict = {"role": "assistant", "content": reply.content or None}
    if reply.tool_calls:
        msg["tool_calls"] = [
            {"id": c.id, "type": "function", "function": {"name": c.name, "arguments": json.dumps(c.arguments)}}
            for c in reply.tool_calls
        ]
    return msg
