"""`vatriage` command line.

vatriage sbom     --pip-report R.json [...] --name APP --version V -o sbom.cdx.json
vatriage collect  --sbom S --bandit B.json --sarif X.sarif --code DIR -o findings.json
vatriage triage   findings.json --code DIR --sbom S [--mode safe|aggressive] [--agent] -o decisions.json
vatriage report   findings.json decisions.json --format md|openvex|sarif -o FILE
vatriage eval     findings.json decisions.json --truth T.yaml [--export-run run.json]
vatriage gate     findings.json decisions.json [--baseline old-decisions.json] [--block P1,P2]
vatriage search   "query" [--package NAME]
vatriage lab      run the whole pipeline on the bundled lab service into out/
"""

from __future__ import annotations

import argparse
import asyncio
import json
import shutil
import subprocess
import sys
import time
from pathlib import Path

from .advisories import KEV, AdvisoryDB
from .evaluate import export_run, load_truth, score
from .models import Decision
from .pipeline import collect
from .reach import CodeIndex
from .report import markdown, openvex, sarif
from .rules import RuleEngine
from .sbom import from_pip_reports, read_cyclonedx, to_cyclonedx
from .workspace import load_findings, save_findings

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_ADV = str(ROOT / "data" / "advisories")
DEFAULT_KEV = str(ROOT / "data" / "kev.json")


def save_decisions(
    path, engine: str, decisions: list[Decision], traces: dict, latency: dict, extra: dict | None = None
):
    Path(path).write_text(
        json.dumps(
            {
                "engine": engine,
                **(extra or {}),
                "decisions": [d.model_dump() for d in decisions],
                "traces": traces,
                "latency_ms": latency,
            },
            indent=1,
        )
    )


def load_decisions(path) -> tuple[dict, list[Decision]]:
    doc = json.loads(Path(path).read_text())
    return doc, [Decision(**d) for d in doc["decisions"]]


def cmd_sbom(a) -> int:
    bom = to_cyclonedx(from_pip_reports(a.pip_report), a.name, a.version)
    Path(a.out).write_text(json.dumps(bom, indent=1))
    print(f"{a.out}: {len(bom['components'])} components")
    return 0


def cmd_collect(a) -> int:
    res = collect(a.sbom, a.bandit, a.sarif, a.advisories, a.kev, a.code)
    save_findings(a.out, res)
    print(
        f"{a.out}: {res['raw_findings']} raw findings, {res['merged']} merged, {len(res['findings'])} unique, "
        f"{sum(f.kev for f in res['findings'])} in CISA KEV"
    )
    return 0


def run_triage(findings_path, code, sbom, advisories, kev, mode, agent=False, agent_scope="review", llm=None):
    meta, findings = load_findings(findings_path)
    _, comps = read_cyclonedx(sbom)
    engine = RuleEngine(CodeIndex.build(code), comps, mode)
    decisions, traces, latency = [], {}, {}
    for f in findings:
        t0 = time.perf_counter()
        d, tr = engine.decide(f)
        decisions.append(d)
        traces[f.key], latency[f.key] = tr, round((time.perf_counter() - t0) * 1000, 3)
    name = f"rules-{mode}"
    if agent:
        name += "+agent"
        server_args = [
            "--findings",
            str(findings_path),
            "--code",
            str(code),
            "--sbom",
            str(sbom),
            "--advisories",
            str(advisories),
        ] + (["--kev", str(kev)] if kev else [])
        decisions = asyncio.run(_agent_pass(findings, decisions, traces, latency, server_args, agent_scope, llm))
    return meta, findings, name, decisions, traces, latency


async def _agent_pass(findings, decisions, traces, latency, server_args, scope, llm):
    from .agent import VAAgent
    from .llm import OpenAICompatLLM

    llm = llm or OpenAICompatLLM()
    by_key = {f.key: f for f in findings}
    out = []
    async with VAAgent(llm, server_args) as agent:
        for d in decisions:
            if scope == "review" and d.status != "needs_review":
                out.append(d)
                continue
            res = await agent.analyse(by_key[d.key], d)
            out.append(res.decision)
            traces[d.key] = traces.get(d.key, []) + res.trace
            latency[d.key] = round(latency.get(d.key, 0) + res.seconds * 1000, 1)
    return out


def cmd_triage(a) -> int:
    meta, findings, name, decisions, traces, latency = run_triage(
        a.findings, a.code, a.sbom, a.advisories, a.kev, a.mode, a.agent, a.agent_scope
    )
    save_decisions(a.out, name, decisions, traces, latency)
    counts = {s: sum(d.status == s for d in decisions) for s in ("affected", "needs_review", "not_affected")}
    print(f"{a.out}: {name}: {counts}")
    return 0


def cmd_report(a) -> int:
    meta, findings = load_findings(a.findings)
    doc, decisions = load_decisions(a.decisions)
    by_key = {f.key: f for f in findings}
    if a.format == "md":
        Path(a.out).write_text(markdown(meta, by_key, decisions, doc["engine"]))
    elif a.format == "openvex":
        Path(a.out).write_text(json.dumps(openvex(meta, by_key, decisions, a.author), indent=1))
    else:
        Path(a.out).write_text(json.dumps(sarif(meta, by_key, decisions), indent=1))
    print(a.out)
    return 0


def cmd_eval(a) -> int:
    _, findings = load_findings(a.findings)
    doc, decisions = load_decisions(a.decisions)
    by_key = {f.key: f for f in findings}
    truth = load_truth(a.truth)
    s = score(by_key, decisions, truth)
    o = s["overall"]
    print(
        f"{doc['engine']}: {o['findings']} findings, automated {o['automated']} ({o['automation_rate']:.0%}), "
        f"accuracy of automated decisions {o['automated_accuracy']:.1%}, needs review {o['needs_review']}"
    )
    print(
        f"  truly affected caught {o['affected_caught']}/{o['truly_affected']}, "
        f"unsafe dismissals {len(o['unsafe_dismissals'])} {o['unsafe_dismissals']}, false alarms {len(o['false_alarms'])}"
    )
    if a.json:
        Path(a.json).write_text(json.dumps(s, indent=1))
    if a.export_run:
        run = export_run(
            a.run_name or doc["engine"],
            doc["engine"],
            by_key,
            decisions,
            truth,
            doc.get("traces"),
            doc.get("latency_ms"),
        )
        Path(a.export_run).write_text(json.dumps(run, indent=1))
        print(f"  run for agent-eval-console: {a.export_run}")
    return 1 if (a.fail_on_unsafe and o["unsafe_dismissals"]) else 0


def cmd_gate(a) -> int:
    _, findings = load_findings(a.findings)
    _, decisions = load_decisions(a.decisions)
    block = set(a.block.split(","))
    accepted: set[str] = set()
    if a.baseline:
        _, base = load_decisions(a.baseline)
        accepted = {d.key for d in base if d.status != "not_affected"}
    blocked = [d for d in decisions if d.status != "not_affected" and d.priority in block and d.key not in accepted]
    for d in blocked:
        print(f"BLOCK {d.priority} {d.status:12s} {d.key}: {(d.guardrail or d.justification)[:120]}")
    print(
        f"gate: {'FAIL' if blocked else 'PASS'} ({len(blocked)} new {'/'.join(sorted(block))} finding(s)"
        f"{', baseline ' + str(len(accepted)) + ' accepted' if a.baseline else ''})"
    )
    return 1 if blocked else 0


def cmd_search(a) -> int:
    from .workspace import Workspace as W

    ws = W({}, {}, Path("."), CodeIndex(Path(".")), [], AdvisoryDB(a.advisories), KEV(None))
    for h in ws.search_advisories(a.query, a.package):
        print(f"{h['id']:18s} {h['package']:14s} {h['score']:6.2f}  {h['summary'][:90]}")
    return 0


def cmd_lab(a) -> int:
    lab = ROOT / "lab" / "netcfg-service"
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    sbom = lab / "sbom" / "netcfg-service.cdx.json"
    bandit_json = out / "bandit.json"
    if shutil.which("bandit"):
        subprocess.run(
            ["bandit", "-r", "app", "tests", "-f", "json", "-o", str(bandit_json.resolve()), "-q"], cwd=lab, check=False
        )
    else:
        shutil.copy(lab / "bandit.json", bandit_json)
    cmd_collect(
        argparse.Namespace(
            sbom=str(sbom),
            bandit=[str(bandit_json)],
            sarif=None,
            advisories=a.advisories,
            kev=a.kev,
            code=str(lab),
            out=str(out / "findings.json"),
        )
    )
    truth = ROOT / "lab" / "ground_truth.yaml"
    for mode in ("safe", "aggressive"):
        dec = out / f"decisions-{mode}.json"
        cmd_triage(
            argparse.Namespace(
                findings=str(out / "findings.json"),
                code=str(lab),
                sbom=str(sbom),
                advisories=a.advisories,
                kev=a.kev,
                mode=mode,
                agent=False,
                agent_scope="review",
                out=str(dec),
            )
        )
        cmd_eval(
            argparse.Namespace(
                findings=str(out / "findings.json"),
                decisions=str(dec),
                truth=str(truth),
                json=str(out / f"score-{mode}.json"),
                export_run=str(out / f"run-rules-{mode}.json"),
                run_name=f"va-rules-{mode}",
                fail_on_unsafe=False,
            )
        )
    for fmt, name in (
        ("md", "va-report.md"),
        ("openvex", "netcfg-service.openvex.json"),
        ("sarif", "va-findings.sarif"),
    ):
        cmd_report(
            argparse.Namespace(
                findings=str(out / "findings.json"),
                decisions=str(out / "decisions-safe.json"),
                format=fmt,
                out=str(out / name),
                author="va-triage-agent",
            )
        )
    return 0


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="vatriage", description="AI-assisted vulnerability analysis triage")
    sub = p.add_subparsers(dest="cmd", required=True)

    def data_args(s):
        s.add_argument("--advisories", default=DEFAULT_ADV)
        s.add_argument("--kev", default=DEFAULT_KEV)

    s = sub.add_parser("sbom")
    s.add_argument("--pip-report", nargs="+", required=True)
    s.add_argument("--name", required=True)
    s.add_argument("--version", required=True)
    s.add_argument("-o", "--out", required=True)
    s.set_defaults(fn=cmd_sbom)

    s = sub.add_parser("collect")
    s.add_argument("--sbom")
    s.add_argument("--bandit", nargs="*")
    s.add_argument("--sarif", nargs="*")
    s.add_argument("--code")
    s.add_argument("-o", "--out", required=True)
    data_args(s)
    s.set_defaults(fn=cmd_collect)

    s = sub.add_parser("triage")
    s.add_argument("findings")
    s.add_argument("--code", required=True)
    s.add_argument("--sbom", required=True)
    s.add_argument("--mode", choices=["safe", "aggressive"], default="safe")
    s.add_argument("--agent", action="store_true", help="LLM agent via MCP (VA_LLM_BASE_URL/API_KEY/MODEL)")
    s.add_argument("--agent-scope", choices=["review", "all"], default="review")
    s.add_argument("-o", "--out", required=True)
    data_args(s)
    s.set_defaults(fn=cmd_triage)

    s = sub.add_parser("report")
    s.add_argument("findings")
    s.add_argument("decisions")
    s.add_argument("--format", choices=["md", "openvex", "sarif"], default="md")
    s.add_argument("--author", default="va-triage-agent")
    s.add_argument("-o", "--out", required=True)
    s.set_defaults(fn=cmd_report)

    s = sub.add_parser("eval")
    s.add_argument("findings")
    s.add_argument("decisions")
    s.add_argument("--truth", required=True)
    s.add_argument("--json")
    s.add_argument("--export-run")
    s.add_argument("--run-name")
    s.add_argument("--fail-on-unsafe", action="store_true")
    s.set_defaults(fn=cmd_eval)

    s = sub.add_parser("gate")
    s.add_argument("findings")
    s.add_argument("decisions")
    s.add_argument("--baseline")
    s.add_argument("--block", default="P1,P2")
    s.set_defaults(fn=cmd_gate)

    s = sub.add_parser("search")
    s.add_argument("query")
    s.add_argument("--package")
    data_args(s)
    s.set_defaults(fn=cmd_search)

    s = sub.add_parser("lab")
    s.add_argument("--out", default="out")
    data_args(s)
    s.set_defaults(fn=cmd_lab)

    a = p.parse_args(argv)
    return a.fn(a)


if __name__ == "__main__":
    sys.exit(main())
