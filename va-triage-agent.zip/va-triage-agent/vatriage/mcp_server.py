"""MCP server with read-only vulnerability-analysis tools (stdio).

    python -m vatriage.mcp_server --findings out/findings.json --code lab/netcfg-service \
        --sbom lab/netcfg-service/sbom/netcfg-service.cdx.json --advisories data/advisories --kev data/kev.json

Any MCP client can use it: the triage agent, an IDE assistant or a desktop chat client.
Every tool is read-only. Advisory text and source code are wrapped in <untrusted> tags: both can contain
text written to manipulate an AI reviewer, so they are data, never instructions.
"""

from __future__ import annotations

import argparse
import json

from mcp.server.mcpserver import MCPServer
from mcp.types import ToolAnnotations

from .workspace import Workspace

READ_ONLY = ToolAnnotations(read_only_hint=True, destructive_hint=False, idempotent_hint=True)


def untrusted(text: str) -> str:
    return f"<untrusted>\n{text}\n</untrusted>"


def build_server(ws: Workspace) -> MCPServer:
    server = MCPServer(
        "va-triage",
        instructions="Read-only tools for vulnerability analysis of one product: findings, source code, "
        "code search, advisories (OSV/PyPA), CISA KEV, SBOM dependency paths and deployment files.",
    )

    @server.tool(annotations=READ_ONLY)
    def get_finding(key: str) -> str:
        """One finding: tool, rule/advisory id, package and version or file and line, severity, CVSS, KEV."""
        return json.dumps(ws.finding(key))

    @server.tool(annotations=READ_ONLY)
    def get_advisory(advisory_id: str) -> str:
        """Full advisory text (PYSEC/GHSA/CVE id), affected and fixed versions, CVSS, CWE and CISA KEV status."""
        return untrusted(json.dumps(ws.advisory(advisory_id), indent=1))

    @server.tool(annotations=READ_ONLY)
    def search_advisories(query: str, package: str | None = None) -> str:
        """Keyword search over all advisories in the local database, e.g. to learn which API a CVE is about."""
        return untrusted(json.dumps(ws.search_advisories(query, package), indent=1))

    @server.tool(annotations=READ_ONLY)
    def find_usages(symbol: str) -> str:
        """Where the service uses a module, class, function, attribute or template filter (file:line + code)."""
        return untrusted(json.dumps(ws.find_usages(symbol), indent=1))

    @server.tool(annotations=READ_ONLY)
    def read_code(path: str, start_line: int = 1, end_line: int = 60) -> str:
        """Numbered source lines of one file of the analysed service (max 150 lines, secrets redacted)."""
        text, _ = ws.read_code(path, start_line, end_line)
        return untrusted(text)

    @server.tool(annotations=READ_ONLY)
    def get_dependency_path(package: str) -> str:
        """SBOM view of a package: direct or transitive, which dependencies pull it in, and where the
        service imports it or its parents."""
        return json.dumps(ws.dependency_path(package), indent=1)

    @server.tool(annotations=READ_ONLY)
    def get_deployment_config() -> str:
        """Deployment files of the service (Kubernetes manifests, Dockerfile, requirements)."""
        return untrusted(json.dumps(ws.deployment_files(), indent=1))

    return server


def main() -> None:
    p = argparse.ArgumentParser(description="VA triage MCP server (stdio)")
    p.add_argument("--findings", required=True)
    p.add_argument("--code", required=True)
    p.add_argument("--sbom", required=True)
    p.add_argument("--advisories", required=True)
    p.add_argument("--kev")
    a = p.parse_args()
    build_server(Workspace.load(a.findings, a.code, a.sbom, a.advisories, a.kev)).run("stdio")


if __name__ == "__main__":
    main()
