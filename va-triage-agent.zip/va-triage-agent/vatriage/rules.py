"""Deterministic triage rules, priorities and guardrails.

Two modes:
- safe        dismiss only when the component is never used by the service; everything else that is
              uncertain goes to human review
- aggressive  also dismiss when none of the code symbols named in the advisory are used

Guardrails apply to every engine (rules and the LLM agent): a CISA KEV or critical (CVSS >= 9.0)
finding is never dismissed without a human.
"""

from __future__ import annotations

import ast
import re
import time

from .models import Decision, Finding
from .reach import CodeIndex, advisory_symbols
from .sbom import Component, dependents

INFORMATIONAL_SAST = {"B404", "B403", "B405", "B406", "B407", "B408", "B409", "B410", "B411", "B412", "B413", "B607"}
INJECTION_SAST = {"B602", "B605", "B606", "B608", "B609", "B610", "B611", "B701", "B702", "B703"}
ALWAYS_TP = {"B501", "B502", "B503", "B504", "B506", "B201", "B307", "B102"}
SECURITY_WORDS = re.compile(r"(token|secret|password|passwd|key|nonce|salt|otp|session|auth|cred)", re.I)
NON_SECURITY_HASH = re.compile(r"(cache|etag|checksum|fingerprint|dedup|shard|bucket)", re.I)


def priority(f: Finding, status: str) -> str:
    if status == "not_affected":
        return "P4"
    if f.kev:
        return "P1"
    sev = f.severity if f.severity != "unknown" else "medium"
    if status == "affected":
        return {"critical": "P1", "high": "P2", "medium": "P3"}.get(sev, "P3")
    return {"critical": "P2", "high": "P2"}.get(sev, "P3")


def apply_guardrails(f: Finding, d: Decision) -> Decision:
    if d.status == "not_affected" and (f.kev or (f.cvss_score or 0) >= 9.0):
        reason = "CISA KEV" if f.kev else f"CVSS {f.cvss_score}"
        d = d.model_copy(
            update={
                "status": "needs_review",
                "needs_human": True,
                "vex_justification": None,
                "guardrail": f"{reason}: dismissal needs human sign-off (proposed: {d.justification})",
            }
        )
    d = d.model_copy(update={"priority": priority(f, d.status)})
    if d.status == "needs_review":
        d = d.model_copy(update={"needs_human": True})
    return d


class RuleEngine:
    def __init__(self, index: CodeIndex, components: list[Component], mode: str = "safe"):
        if mode not in ("safe", "aggressive"):
            raise ValueError("mode must be safe or aggressive")
        self.index, self.mode = index, mode
        self.components = {c.name.lower().replace("_", "-"): c for c in components}
        self.parents = dependents(components)

    def decide(self, f: Finding) -> tuple[Decision, list[dict]]:
        trace: list[dict] = []
        t0 = time.perf_counter()
        d = self._sca(f, trace) if f.source == "sca" else self._sast(f, trace)
        d = apply_guardrails(f, d)
        if d.guardrail:
            trace.append(
                {
                    "kind": "guardrail",
                    "name": "kev/critical dismissal",
                    "input": "",
                    "output": d.guardrail,
                    "duration_ms": 0.0,
                }
            )
        trace.append(
            {
                "kind": "rule",
                "name": f"rules ({self.mode})",
                "input": f.key,
                "output": f"{d.status} {d.priority}: {d.justification}",
                "duration_ms": round((time.perf_counter() - t0) * 1000, 3),
            }
        )
        return d, trace

    # -- dependency findings -----------------------------------------------------------------------
    def _sca(self, f: Finding, trace: list[dict]) -> Decision:
        pkg = f.package or ""
        uses = self.index.imported(pkg)
        trace.append(
            {
                "kind": "tool",
                "name": "code_index.imported",
                "input": pkg,
                "output": "; ".join(f"{u.file}:{u.line}" for u in uses[:5]) or "not imported",
                "duration_ms": 0.0,
            }
        )
        if uses:
            return self._direct(f, uses, trace)
        parents = [p for p in self.parents.get(pkg, []) if p != pkg]
        used_parents = [p for p in parents if self.index.imported(p)]
        if parents and used_parents:
            return Decision(
                key=f.key,
                status="needs_review",
                priority="P3",
                justification=f"{pkg} is used indirectly through {', '.join(used_parents)}; "
                "function-level reachability needs analysis",
                evidence=[f"sbom: {p} -> {pkg}" for p in used_parents],
            )
        via = f" (only pulled in by {', '.join(parents)}, which is not imported)" if parents else ""
        return Decision(
            key=f.key,
            status="not_affected",
            priority="P4",
            vex_justification="vulnerable_code_not_in_execute_path",
            justification=f"{pkg} is installed but never imported by the service{via}",
            evidence=[f"code index: no import of {pkg}"],
        )

    def _direct(self, f: Finding, uses, trace: list[dict]) -> Decision:
        syms = advisory_symbols(f"{f.title}\n{f.details}", f.package or "")
        hits = {s: self.index.find(s) for s in sorted(syms)}
        hits = {s: u for s, u in hits.items() if u}
        trace.append(
            {
                "kind": "tool",
                "name": "advisory_symbols+code_index.find",
                "input": ", ".join(sorted(syms)),
                "output": "; ".join(f"{s} @ {u[0].file}:{u[0].line}" for s, u in hits.items()) or "no symbol used",
                "duration_ms": 0.0,
            }
        )
        imported_at = f"{uses[0].file}:{uses[0].line}"
        if hits:
            s, u = next(iter(hits.items()))
            return Decision(
                key=f.key,
                status="affected",
                priority="P3",
                justification=f"advisory names {s}, which the service uses at {u[0].file}:{u[0].line}",
                evidence=[f"{x.file}:{x.line}" for x in u[:3]] + [f.rule_id],
            )
        if syms and self.mode == "aggressive":
            return Decision(
                key=f.key,
                status="not_affected",
                priority="P4",
                vex_justification="vulnerable_code_not_in_execute_path",
                justification=f"none of the APIs named in the advisory ({', '.join(sorted(syms)[:6])}) "
                "are used by the service",
                evidence=[f"imported at {imported_at}", f.rule_id],
            )
        why = "advisory names no specific API" if not syms else "named APIs not found, but absence is not proof"
        return Decision(
            key=f.key,
            status="needs_review",
            priority="P3",
            justification=f"{f.package} is imported ({imported_at}); {why}",
            evidence=[imported_at, f.rule_id],
        )

    # -- code findings -----------------------------------------------------------------------------
    def _sast(self, f: Finding, trace: list[dict]) -> Decision:
        loc = f"{f.file}:{f.line}"
        if f.file and (f.file.startswith("tests/") or "/tests/" in f.file or f.file.split("/")[-1].startswith("test_")):
            return Decision(
                key=f.key,
                status="not_affected",
                priority="P4",
                vex_justification="vulnerable_code_not_in_execute_path",
                justification="finding is in test code, which is not shipped",
                evidence=[loc],
            )
        if f.rule_id in INFORMATIONAL_SAST:
            return Decision(
                key=f.key,
                status="not_affected",
                priority="P4",
                vex_justification="vulnerable_code_not_present",
                justification="informational check (import or partial path), not a vulnerability by itself",
                evidence=[loc],
            )
        if f.rule_id in ALWAYS_TP:
            return Decision(
                key=f.key,
                status="affected",
                priority="P3",
                justification=f"{f.rule_id} has no safe form in production code",
                evidence=[loc],
            )
        call = self.index.call_at(f.file or "", f.line or 0)
        trace.append(
            {
                "kind": "tool",
                "name": "code_index.call_at",
                "input": loc,
                "output": ast.unparse(call)[:300] if call else "no call found",
                "duration_ms": 0.0,
            }
        )
        if f.rule_id in INJECTION_SAST and call is not None and call.args:
            if self.index.is_constant_expr(f.file or "", call.args[0]):
                return Decision(
                    key=f.key,
                    status="not_affected",
                    priority="P4",
                    vex_justification="vulnerable_code_cannot_be_controlled_by_adversary",
                    justification="command/query is built only from literals and module constants",
                    evidence=[loc],
                )
            return Decision(
                key=f.key,
                status="affected",
                priority="P3",
                justification="command/query is built from non-constant input",
                evidence=[loc],
            )
        func = self.index.enclosing_function(f.file or "", f.line or 0) or ""
        line_text = (self.index.snippet(f.file or "", f.line or 0, f.line or 0) or [(0, "")])[0][1]
        if f.rule_id == "B311":
            target = line_text.split("=")[0] if "=" in line_text else ""
            if SECURITY_WORDS.search(func) or SECURITY_WORDS.search(target):
                return Decision(
                    key=f.key,
                    status="affected",
                    priority="P3",
                    justification=f"non-cryptographic PRNG used in security context ({func})",
                    evidence=[loc],
                )
            return Decision(
                key=f.key,
                status="not_affected",
                priority="P4",
                vex_justification="vulnerable_code_not_present",
                justification=f"PRNG used for non-security purpose ({func})",
                evidence=[loc],
            )
        if f.rule_id in ("B105", "B106", "B107"):
            m = re.search(r"""(["'])(.*?)\1""", line_text)
            value = m.group(2) if m else ""
            from .pipeline import looks_secret

            if looks_secret(value):
                return Decision(
                    key=f.key,
                    status="affected",
                    priority="P3",
                    justification="literal looks like a real credential",
                    evidence=[loc],
                )
            return Decision(
                key=f.key,
                status="not_affected",
                priority="P4",
                vex_justification="vulnerable_code_not_present",
                justification="literal is a field name or placeholder, not a credential",
                evidence=[loc],
            )
        if f.rule_id in ("B303", "B324"):
            if "usedforsecurity=False" in line_text or NON_SECURITY_HASH.search(func + " " + line_text):
                return Decision(
                    key=f.key,
                    status="not_affected",
                    priority="P4",
                    vex_justification="vulnerable_code_not_present",
                    justification=f"weak hash used for a non-security purpose ({func})",
                    evidence=[loc],
                )
            return Decision(
                key=f.key,
                status="affected",
                priority="P3",
                justification="weak hash in a possible security context",
                evidence=[loc],
            )
        return Decision(
            key=f.key, status="needs_review", priority="P3", justification=f"no rule for {f.rule_id}", evidence=[loc]
        )
