"""Outputs: a VA report in Markdown, OpenVEX statements, and SARIF for CI code scanning."""

from __future__ import annotations

import hashlib
from collections import Counter, defaultdict
from datetime import UTC, datetime

from packaging.version import InvalidVersion, Version

from .models import Decision, Finding

PRIO = {"P1": 0, "P2": 1, "P3": 2, "P4": 3}
VEX_STATUS = {"affected": "affected", "not_affected": "not_affected", "needs_review": "under_investigation"}


def _vid(f: Finding) -> str:
    return next((a for a in f.aliases if a.startswith("CVE-")), f.rule_id)


def _where(f: Finding) -> str:
    return f"{f.package} {f.version}" if f.source == "sca" else f"{f.file}:{f.line}"


def _cell(text: str | None) -> str:
    return (text or "").replace("|", "\\|").replace("\n", " ")


def remediation(findings: dict[str, Finding], decisions: list[Decision]) -> list[dict]:
    """Smallest upgrade per package that fixes every open (affected or needs_review) advisory."""
    open_by_pkg: dict[str, list[Finding]] = defaultdict(list)
    for d in decisions:
        f = findings[d.key]
        if f.source == "sca" and d.status != "not_affected":
            open_by_pkg[(f.package, f.version)].append(f)
    plan = []
    for (pkg, ver), fs in sorted(open_by_pkg.items()):
        fixes, unfixed = [], []
        for f in fs:
            vs = []
            for v in f.fixed_in:
                try:
                    vs.append(Version(v))
                except InvalidVersion:
                    continue
            (fixes.append(min(vs)) if vs else unfixed.append(_vid(f)))
        plan.append(
            {
                "package": pkg,
                "from": ver,
                "to": str(max(fixes)) if fixes else None,
                "fixes": len(fs) - len(unfixed),
                "no_fix_available": unfixed,
            }
        )
    return plan


def markdown(meta: dict, findings: dict[str, Finding], decisions: list[Decision], engine: str) -> str:
    by_status = Counter(d.status for d in decisions)
    by_source = Counter(findings[d.key].source for d in decisions)
    open_items = sorted((d for d in decisions if d.status != "not_affected"), key=lambda d: (PRIO[d.priority], d.key))
    closed = sorted((d for d in decisions if d.status == "not_affected"), key=lambda d: d.key)
    tools = sorted({findings[d.key].tool for d in decisions})
    now = datetime.now(UTC).strftime("%Y-%m-%d %H:%M UTC")
    out = [
        f"# Vulnerability analysis report: {meta.get('product', 'unknown')}",
        "",
        f"Generated {now} by va-triage-agent ({engine}). Decisions marked *needs human* are proposals until a "
        "security engineer signs them off.",
        "",
        "## Summary",
        "",
        f"- Tools: {', '.join(tools)}; advisories: PyPA/OSV snapshot; CISA KEV catalog {meta.get('kev_catalog')}",
        f"- Findings: {meta.get('raw_findings')} raw, {meta.get('merged', 0)} duplicates merged, "
        f"{len(decisions)} analysed ({by_source['sca']} dependency, {by_source['sast']} code)",
        f"- Affected: **{by_status['affected']}**, needs review: **{by_status['needs_review']}**, "
        f"not affected / false positive: **{by_status['not_affected']}**",
        "- Open by priority: " + ", ".join(f"{p} {sum(1 for d in open_items if d.priority == p)}" for p in PRIO),
        "",
        "## Remaining findings",
        "",
        "| Pri | Finding | Where | Severity | Status | Why | Evidence |",
        "| --- | --- | --- | --- | --- | --- | --- |",
    ]
    for d in open_items:
        f = findings[d.key]
        sev = f"{f.severity}" + (f" ({f.cvss_score})" if f.cvss_score else "") + (" **KEV**" if f.kev else "")
        status = d.status + (" (needs human)" if d.needs_human else "")
        out.append(
            f"| {d.priority} | {_vid(f)} {_cell(f.title)[:70]} | {_where(f)} | {sev} | {status} | "
            f"{_cell(d.guardrail or d.justification)[:160]} | {_cell(', '.join(d.evidence[:3]))} |"
        )
    plan = remediation(findings, decisions)
    if plan:
        out += [
            "",
            "## Remediation plan (dependencies)",
            "",
            "| Package | Current | Upgrade to | Open advisories fixed |",
            "| --- | --- | --- | --- |",
        ]
        for p in plan:
            nofix = f" (no fix yet: {', '.join(p['no_fix_available'])})" if p["no_fix_available"] else ""
            out.append(f"| {p['package']} | {p['from']} | {p['to'] or 'n/a'} | {p['fixes']}{nofix} |")
    out += [
        "",
        "## Not affected and false positives",
        "",
        "| Finding | Where | Justification (OpenVEX) | Reason |",
        "| --- | --- | --- | --- |",
    ]
    for d in closed:
        f = findings[d.key]
        out.append(f"| {_vid(f)} | {_where(f)} | {d.vex_justification or '-'} | {_cell(d.justification)[:160]} |")
    out += [
        "",
        "## Method",
        "",
        "Dependency findings come from matching the SBOM against OSV advisories; code findings from static "
        "analysis. Each finding is checked for reachability in the service code (imports, API and template-"
        "filter use, constant-only inputs). KEV or critical findings are never closed without a human.",
        "",
    ]
    return "\n".join(out)


def openvex(meta: dict, findings: dict[str, Finding], decisions: list[Decision], author: str) -> dict:
    product = meta.get("product", "app@unknown")
    name, _, version = product.partition("@")
    app_purl = f"pkg:generic/{name}@{version}"
    stmts = []
    for d in sorted(decisions, key=lambda d: d.key):
        f = findings[d.key]
        if f.source != "sca":
            continue
        s = {
            "vulnerability": {"name": _vid(f), "aliases": [a for a in [f.rule_id, *f.aliases] if a != _vid(f)]},
            "products": [{"@id": app_purl, "subcomponents": [{"@id": f"pkg:pypi/{f.package}@{f.version}"}]}],
            "status": VEX_STATUS[d.status],
        }
        if d.status == "not_affected":
            s["justification"] = d.vex_justification or "vulnerable_code_not_in_execute_path"
            s["impact_statement"] = d.justification
        elif d.status == "affected":
            s["action_statement"] = (
                f"Upgrade {f.package} to {f.fixed_in[0]} or later"
                if f.fixed_in
                else "No fixed version yet; apply a mitigation"
            )
        else:
            s["status_notes"] = d.guardrail or d.justification
        stmts.append(s)
    digest = hashlib.sha256(repr([(s["vulnerability"]["name"], s["status"]) for s in stmts]).encode()).hexdigest()[:16]
    return {
        "@context": "https://openvex.dev/ns/v0.2.0",
        "@id": f"https://openvex.dev/docs/va-triage/{digest}",
        "author": author,
        "timestamp": datetime.now(UTC).isoformat(timespec="seconds"),
        "version": 1,
        "statements": stmts,
    }


SARIF_LEVEL = {"P1": "error", "P2": "error", "P3": "warning", "P4": "note"}


def sarif(meta: dict, findings: dict[str, Finding], decisions: list[Decision]) -> dict:
    rules, results = {}, []
    for d in sorted(decisions, key=lambda d: (PRIO[d.priority], d.key)):
        if d.status == "not_affected":
            continue
        f = findings[d.key]
        rid = f.rule_id
        rules.setdefault(
            rid,
            {
                "id": rid,
                "shortDescription": {"text": f.title[:200]},
                "properties": {
                    "tags": ["security", *f.cwe],
                    **({"security-severity": str(f.cvss_score)} if f.cvss_score else {}),
                },
            },
        )
        uri, line = (f.file, f.line or 1) if f.source == "sast" else ("requirements.txt", 1)
        results.append(
            {
                "ruleId": rid,
                "level": SARIF_LEVEL[d.priority],
                "message": {"text": f"[{d.priority} {d.status}] {f.title} - {d.guardrail or d.justification}"},
                "locations": [{"physicalLocation": {"artifactLocation": {"uri": uri}, "region": {"startLine": line}}}],
                "partialFingerprints": {"vaTriageKey": d.key},
            }
        )
    return {
        "$schema": "https://json.schemastore.org/sarif-2.1.0.json",
        "version": "2.1.0",
        "runs": [
            {
                "tool": {
                    "driver": {
                        "name": "va-triage-agent",
                        "informationUri": "https://github.com/narendra-sagar-velpula/va-triage-agent",
                        "rules": list(rules.values()),
                    }
                },
                "results": results,
            }
        ],
    }
