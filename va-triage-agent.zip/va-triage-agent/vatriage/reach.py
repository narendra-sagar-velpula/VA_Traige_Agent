"""Code index for reachability: which packages are imported, which APIs are called, which template
filters are used, and whether a flagged call only gets constant input.

This is a static, best-effort index. It answers "is this symbol used?", not "can an attacker reach it?".
"""

from __future__ import annotations

import ast
import builtins
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path

from .advisories import normalize

# import name -> distribution name, where they differ
IMPORT_TO_DIST = {
    "PIL": "pillow",
    "yaml": "pyyaml",
    "nacl": "pynacl",
    "OpenSSL": "pyopenssl",
    "jwt": "pyjwt",
    "bs4": "beautifulsoup4",
    "sklearn": "scikit-learn",
    "cv2": "opencv-python",
    "dateutil": "python-dateutil",
    "Crypto": "pycryptodome",
    "google.protobuf": "protobuf",
    "attr": "attrs",
    "markupsafe": "markupsafe",
}

GENERIC = {
    "open",
    "load",
    "read",
    "save",
    "encode",
    "decode",
    "get",
    "run",
    "apply",
    "eval",
    "new",
    "seek",
    "update",
    "filter",
    "format",
    "close",
    "write",
    "call",
    "init",
    "main",
    "data",
    "file",
    "self",
    "this",
    "that",
    "with",
    "from",
    "none",
    "true",
    "false",
    "attr",
    "http",
    "https",
}
PROSE_CAMEL = {
    "JavaScript",
    "GitHub",
    "PyPI",
    "TypeScript",
    "MacOs",
    "PowerShell",
    "LibreOffice",
    "WebKit",
    "YouTube",
    "DoS",
    "ReDoS",
    "OpenSsl",
    "CentOs",
    "RedHat",
    "LinkedIn",
    "PostgreSql",
    "MySql",
}

BACKTICK = re.compile(r"`([^`]{2,120})`")
DOTTED = re.compile(r"\b([A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)+)(?:\(\))?")
CAMEL = re.compile(r"\b([A-Z][a-z0-9]+(?:[A-Z][a-z0-9]+)+)\b")
SNAKE = re.compile(r"\b(_?[a-z][a-z0-9]*(?:_[a-z0-9]+)+)\b")
CALL = re.compile(r"\b([A-Za-z_][A-Za-z0-9_]{2,})\(\)")
IDENT = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")
FILTER_RE = re.compile(r"\|\s*([a-z_][a-z0-9_]*)")
FILE_EXT = re.compile(r"\.(c|h|py|cc|cpp|rs|js)$")
FENCED = re.compile(r"```.*?```", re.S)
BUILTINS = set(dir(builtins))
STDLIB = set(sys.stdlib_module_names)
STDLIB_CLASSES = {
    "BytesIO",
    "StringIO",
    "Path",
    "PurePath",
    "OrderedDict",
    "defaultdict",
    "Counter",
    "Thread",
    "Popen",
    "TemporaryFile",
    "NamedTemporaryFile",
    "SSLContext",
    "HTTPConnection",
}


def advisory_symbols(text: str, package: str) -> set[str]:
    """Code-like names mentioned in an advisory: dotted APIs, CamelCase classes, snake_case functions,
    calls written as name(), and anything in backticks."""
    text = FENCED.sub(" ", text)  # example code in advisories is noise, not the vulnerable API
    syms: set[str] = set()
    for chunk in BACKTICK.findall(text):
        chunk = chunk.strip().removesuffix("()")
        if re.fullmatch(r"\|\s*[a-z_][a-z0-9_]*", chunk):  # a template filter like |attr
            syms.add(chunk.lstrip("| "))
        elif re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)*", chunk):
            syms.add(chunk)
    for d in DOTTED.findall(text):
        if FILE_EXT.search(d) or re.fullmatch(r"[\d.]+", d) or d.count(".") > 4:
            continue
        if any(p[:1].isupper() for p in d.split(".")) or "_" in d or d.lower().startswith(normalize(package)):
            syms.add(d)
    syms.update(c for c in CAMEL.findall(text) if c not in PROSE_CAMEL)
    syms.update(SNAKE.findall(text))
    syms.update(CALL.findall(text))
    pkg = normalize(package).replace("-", "")
    out = set()
    for s in syms:
        s = FILE_EXT.sub("", s)
        first, last = s.split(".")[0], s.split(".")[-1]
        if (
            s in BUILTINS
            or s in STDLIB_CLASSES
            or ("." in s and first in STDLIB)
            or ("." in s and first in BUILTINS)
            or last in STDLIB_CLASSES
        ):
            continue
        if last.lower() in GENERIC and "." not in s:
            continue
        if s.lower().replace("_", "") in (pkg, "python", "pillow", "jinja", "jinja2", "pyyaml", "urllib3"):
            continue
        if len(last) < 4 and "." not in s:
            continue
        out.add(s)
    return out


@dataclass
class Use:
    file: str
    line: int
    text: str


@dataclass
class CodeIndex:
    root: Path
    imports: dict[str, list[Use]] = field(default_factory=dict)  # distribution -> uses
    names: dict[str, list[Use]] = field(default_factory=dict)  # identifier -> uses
    chains: dict[str, list[Use]] = field(default_factory=dict)  # "Image.open" -> uses
    lines: dict[str, list[str]] = field(default_factory=dict)
    trees: dict[str, ast.Module] = field(default_factory=dict)

    @classmethod
    def build(cls, root: str | Path, include_tests: bool = False) -> CodeIndex:
        idx = cls(Path(root))
        for path in sorted(idx.root.rglob("*")):
            rel = path.relative_to(idx.root).as_posix()
            if not path.is_file() or any(p.startswith(".") for p in path.parts):
                continue
            if not include_tests and (rel.startswith("tests/") or "/tests/" in rel):
                continue
            if path.suffix == ".py":
                idx._index_python(rel, path.read_text(encoding="utf-8", errors="replace"))
            elif path.suffix in (".j2", ".jinja", ".jinja2", ".html"):
                idx._index_template(rel, path.read_text(encoding="utf-8", errors="replace"))
        return idx

    def _add(self, table: dict, key: str, rel: str, line: int) -> None:
        text = self.lines[rel][line - 1].strip() if 0 < line <= len(self.lines[rel]) else ""
        table.setdefault(key, []).append(Use(rel, line, text))

    def _index_python(self, rel: str, src: str) -> None:
        self.lines[rel] = src.splitlines()
        try:
            tree = ast.parse(src)
        except SyntaxError:
            return
        self.trees[rel] = tree
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for a in node.names:
                    self._add(self.imports, _dist(a.name), rel, node.lineno)
                    self._add(self.names, (a.asname or a.name).split(".")[0], rel, node.lineno)
            elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
                self._add(self.imports, _dist(node.module), rel, node.lineno)
                for a in node.names:
                    self._add(self.names, a.asname or a.name, rel, node.lineno)
            elif isinstance(node, ast.Attribute):
                self._add(self.names, node.attr, rel, node.lineno)
                chain = _chain(node)
                if chain:
                    parts = chain.split(".")
                    self._add(self.chains, ".".join(parts[-2:]), rel, node.lineno)
            elif isinstance(node, ast.Name):
                self._add(self.names, node.id, rel, node.lineno)

    def _index_template(self, rel: str, src: str) -> None:
        self.lines[rel] = src.splitlines()
        for i, line in enumerate(self.lines[rel], 1):
            for f in FILTER_RE.findall(line):
                self._add(self.names, f, rel, i)
                self._add(self.chains, f"filter.{f}", rel, i)

    # -- queries ------------------------------------------------------------------------------------
    def imported(self, dist: str) -> list[Use]:
        return self.imports.get(normalize(dist), [])

    def find(self, symbol: str) -> list[Use]:
        """Where is `symbol` used? Dotted names match on their last two parts (Image.open)."""
        parts = symbol.split(".")
        if len(parts) >= 2:
            return self.chains.get(".".join(parts[-2:]), [])
        return self.names.get(symbol, []) + self.chains.get(f"filter.{symbol}", [])

    def snippet(self, rel: str, start: int, end: int) -> list[tuple[int, str]]:
        lines = self.lines.get(rel) or []
        start, end = max(1, start), min(len(lines), end)
        return [(i, lines[i - 1]) for i in range(start, end + 1)]

    def call_at(self, rel: str, line: int) -> ast.Call | None:
        tree = self.trees.get(rel)
        if tree is None:
            return None
        calls = [
            n for n in ast.walk(tree) if isinstance(n, ast.Call) and n.lineno <= line <= (n.end_lineno or n.lineno)
        ]
        return min(calls, key=lambda c: (c.end_lineno or c.lineno) - c.lineno, default=None)

    def enclosing_function(self, rel: str, line: int) -> str | None:
        tree = self.trees.get(rel)
        best = None
        for n in ast.walk(tree) if tree else []:
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.lineno <= line <= (
                n.end_lineno or n.lineno
            ):
                best = n.name
        return best

    def module_constants(self, rel: str) -> set[str]:
        tree = self.trees.get(rel)
        out = set()
        for n in tree.body if tree else []:
            if isinstance(n, ast.Assign) and isinstance(n.value, ast.Constant):
                out.update(t.id for t in n.targets if isinstance(t, ast.Name))
        return out

    def is_constant_expr(self, rel: str, expr: ast.AST) -> bool:
        """True when the expression is a literal, or an f-string/concatenation of literals and
        module-level constants only."""
        consts = self.module_constants(rel)
        if isinstance(expr, ast.Constant):
            return True
        if isinstance(expr, ast.Name):
            return expr.id in consts
        if isinstance(expr, ast.JoinedStr):
            return all(
                isinstance(v, ast.Constant)
                or (isinstance(v, ast.FormattedValue) and self.is_constant_expr(rel, v.value))
                for v in expr.values
            )
        if isinstance(expr, ast.BinOp):
            return self.is_constant_expr(rel, expr.left) and self.is_constant_expr(rel, expr.right)
        return False


def _dist(module: str) -> str:
    for imp, dist in IMPORT_TO_DIST.items():
        if module == imp or module.startswith(imp + "."):
            return dist
    return normalize(module.split(".")[0])


def _chain(node: ast.Attribute) -> str | None:
    parts = [node.attr]
    cur = node.value
    while isinstance(cur, ast.Attribute):
        parts.append(cur.attr)
        cur = cur.value
    if isinstance(cur, ast.Name):
        parts.append(cur.id)
        return ".".join(reversed(parts))
    return None
