"""SBOMs: build CycloneDX 1.5 JSON from `pip install --dry-run --report` output, and read CycloneDX."""

from __future__ import annotations

import json
import re
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path

from .advisories import normalize

REQ_NAME = re.compile(r"^\s*([A-Za-z0-9][A-Za-z0-9._-]*)")


@dataclass
class Component:
    name: str
    version: str
    direct: bool
    depends_on: list[str] = field(default_factory=list)

    @property
    def purl(self) -> str:
        return f"pkg:pypi/{normalize(self.name)}@{self.version}"


def from_pip_reports(paths: list[str | Path]) -> list[Component]:
    comps: dict[str, Component] = {}
    raw_deps: dict[str, list[str]] = {}
    for p in paths:
        for item in json.loads(Path(p).read_text())["install"]:
            m = item["metadata"]
            key = normalize(m["name"])
            comps[key] = Component(m["name"], m["version"], bool(item.get("requested")))
            reqs = [r for r in (m.get("requires_dist") or []) if "extra ==" not in r]
            raw_deps[key] = [normalize(REQ_NAME.match(r).group(1)) for r in reqs if REQ_NAME.match(r)]
    for key, deps in raw_deps.items():
        comps[key].depends_on = sorted({d for d in deps if d in comps})
    return sorted(comps.values(), key=lambda c: normalize(c.name))


def to_cyclonedx(components: list[Component], app_name: str, app_version: str) -> dict:
    app_ref = f"pkg:generic/{app_name}@{app_version}"
    by_name = {normalize(c.name): c for c in components}
    return {
        "bomFormat": "CycloneDX",
        "specVersion": "1.5",
        "version": 1,
        "serialNumber": f"urn:uuid:{uuid.uuid5(uuid.NAMESPACE_URL, app_ref + ''.join(c.purl for c in components))}",
        "metadata": {
            "timestamp": datetime.now(UTC).isoformat(timespec="seconds"),
            "tools": {"components": [{"type": "application", "name": "vatriage sbom"}]},
            "component": {"type": "application", "name": app_name, "version": app_version, "bom-ref": app_ref},
        },
        "components": [
            {
                "type": "library",
                "name": c.name,
                "version": c.version,
                "purl": c.purl,
                "bom-ref": c.purl,
                "scope": "required",
            }
            for c in components
        ],
        "dependencies": [{"ref": app_ref, "dependsOn": [c.purl for c in components if c.direct]}]
        + [{"ref": c.purl, "dependsOn": [by_name[d].purl for d in c.depends_on]} for c in components],
    }


def read_cyclonedx(path: str | Path) -> tuple[str, list[Component]]:
    doc = json.loads(Path(path).read_text())
    app = doc.get("metadata", {}).get("component", {})
    app_ref = app.get("bom-ref")
    ref_to_name = {}
    comps: dict[str, Component] = {}
    for c in doc.get("components", []):
        purl = c.get("purl") or ""
        if not purl.startswith("pkg:pypi/"):
            continue
        ref_to_name[c.get("bom-ref", purl)] = normalize(c["name"])
        comps[normalize(c["name"])] = Component(c["name"], c["version"], False)
    for d in doc.get("dependencies", []):
        targets = [ref_to_name[t] for t in d.get("dependsOn", []) if t in ref_to_name]
        if d["ref"] == app_ref:
            for t in targets:
                comps[t].direct = True
        elif d["ref"] in ref_to_name:
            comps[ref_to_name[d["ref"]]].depends_on = sorted(set(targets))
    return f"{app.get('name', 'app')}@{app.get('version', '?')}", list(comps.values())


def dependents(components: list[Component]) -> dict[str, list[str]]:
    """For each package, the direct dependencies of the app that pull it in (transitively)."""
    by = {normalize(c.name): c for c in components}
    out: dict[str, set[str]] = {k: set() for k in by}
    for root in (c for c in components if c.direct):
        stack, seen = [normalize(root.name)], set()
        while stack:
            cur = stack.pop()
            if cur in seen:
                continue
            seen.add(cur)
            out[cur].add(normalize(root.name))
            stack.extend(by[cur].depends_on if cur in by else [])
    return {k: sorted(v) for k, v in out.items()}
