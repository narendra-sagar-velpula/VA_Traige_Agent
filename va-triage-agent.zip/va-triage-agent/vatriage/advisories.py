"""OSV advisories for PyPI (from the PyPA advisory database) and the CISA KEV catalog.

- version matching follows OSV semantics: explicit `versions`, or ECOSYSTEM ranges with
  introduced / fixed / last_affected events
- BM25 keyword search over advisory text, so the agent can look up related advisories
"""

from __future__ import annotations

import json
import math
import re
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path

import yaml
from packaging.version import InvalidVersion, Version

from . import cvss


def normalize(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name).lower()


@dataclass
class Advisory:
    id: str
    package: str
    details: str
    summary: str
    aliases: list[str]
    ranges: list[list[dict]]
    versions: set[str]
    severity_vector: str | None = None
    cvss_score: float | None = None
    cwe: list[str] = field(default_factory=list)
    references: list[str] = field(default_factory=list)

    @property
    def cve(self) -> str | None:
        return next((a for a in [self.id, *self.aliases] if a.startswith("CVE-")), None)

    def fixed_versions(self) -> list[str]:
        return sorted({e["fixed"] for r in self.ranges for e in r if "fixed" in e}, key=_vkey)

    def affects(self, version: str) -> bool:
        if version in self.versions:
            return True
        try:
            v = Version(version)
        except InvalidVersion:
            return False
        for events in self.ranges:
            affected = False
            for e in sorted(events, key=_event_key):
                if "introduced" in e and (e["introduced"] == "0" or v >= Version(e["introduced"])):
                    affected = True
                elif "fixed" in e and v >= Version(e["fixed"]):
                    affected = False
                elif "last_affected" in e and v > Version(e["last_affected"]):
                    affected = False
            if affected:
                return True
        return False


def _vkey(s: str):
    try:
        return (0, Version(s))
    except InvalidVersion:
        return (1, s)


def _event_key(e: dict):
    value = next(iter(e.values()))
    if value == "0":
        return (Version("0"), 0)
    try:
        return (Version(value), 0 if "introduced" in e else 1)
    except InvalidVersion:
        return (Version("0"), 2)


def _from_osv(doc: dict, package: str) -> Advisory:
    ranges, versions = [], set()
    for aff in doc.get("affected", []):
        if normalize(aff.get("package", {}).get("name", "")) != package:
            continue
        versions.update(aff.get("versions") or [])
        for r in aff.get("ranges") or []:
            if r.get("type") == "ECOSYSTEM":
                ranges.append(r.get("events") or [])
    vector = score = None
    for s in doc.get("severity") or []:
        if s.get("type") == "CVSS_V3":
            vector = s["score"]
            try:
                score = cvss.base_score(vector)
            except (ValueError, KeyError):
                score = None
            break
    cwe = sorted({c for c in (doc.get("database_specific") or {}).get("cwe_ids", []) if c.startswith("CWE-")})
    return Advisory(
        id=doc["id"],
        package=package,
        details=(doc.get("details") or "").strip(),
        summary=(doc.get("summary") or "").strip(),
        aliases=list(doc.get("aliases") or []),
        ranges=ranges,
        versions=versions,
        severity_vector=vector,
        cvss_score=score,
        cwe=cwe,
        references=[r["url"] for r in doc.get("references") or [] if r.get("url")][:5],
    )


class AdvisoryDB:
    """Loads `<root>/<package>/*.yaml|json` (the layout of github.com/pypa/advisory-database/vulns)."""

    def __init__(self, root: str | Path):
        self.root = Path(root)
        self._cache: dict[str, list[Advisory]] = {}

    def for_package(self, name: str) -> list[Advisory]:
        pkg = normalize(name)
        if pkg not in self._cache:
            out = []
            d = next((p for p in (self.root / pkg, self.root / name) if p.is_dir()), None)
            if d:
                for f in sorted(d.iterdir()):
                    if f.suffix in (".yaml", ".yml"):
                        doc = yaml.safe_load(f.read_text())
                    elif f.suffix == ".json":
                        doc = json.loads(f.read_text())
                    else:
                        continue
                    if doc.get("withdrawn"):
                        continue
                    out.append(_from_osv(doc, pkg))
            self._cache[pkg] = out
        return self._cache[pkg]

    def matching(self, name: str, version: str) -> list[Advisory]:
        return [a for a in self.for_package(name) if a.affects(version)]

    def get(self, advisory_id: str) -> Advisory | None:
        for d in self.root.iterdir() if self.root.is_dir() else []:
            if d.is_dir():
                for a in self.for_package(d.name):
                    if a.id == advisory_id or advisory_id in a.aliases:
                        return a
        return None

    def all(self) -> list[Advisory]:
        return [a for d in sorted(self.root.iterdir()) if d.is_dir() for a in self.for_package(d.name)]


class KEV:
    def __init__(self, path: str | Path | None):
        self.entries: dict[str, dict] = {}
        self.version = None
        if path and Path(path).exists():
            doc = json.loads(Path(path).read_text())
            self.version = doc.get("catalogVersion")
            self.entries = {v["cveID"]: v for v in doc.get("vulnerabilities", [])}

    def lookup(self, ids: list[str]) -> dict | None:
        return next((self.entries[i] for i in ids if i in self.entries), None)


TOKEN = re.compile(r"[a-z0-9_]+")


class BM25:
    """Small BM25 index used for advisory knowledge retrieval."""

    def __init__(self, docs: list[tuple[str, str]], k1: float = 1.5, b: float = 0.75):
        self.ids = [i for i, _ in docs]
        self.tokens = [TOKEN.findall(t.lower()) for _, t in docs]
        self.k1, self.b = k1, b
        self.avg = sum(map(len, self.tokens)) / max(len(self.tokens), 1)
        df: Counter = Counter()
        for toks in self.tokens:
            df.update(set(toks))
        n = len(self.tokens)
        self.idf = {t: math.log(1 + (n - f + 0.5) / (f + 0.5)) for t, f in df.items()}
        self.tf = [Counter(t) for t in self.tokens]

    def search(self, query: str, k: int = 5) -> list[tuple[str, float]]:
        q = TOKEN.findall(query.lower())
        scores = []
        for i, tf in enumerate(self.tf):
            dl = len(self.tokens[i])
            s = sum(
                self.idf.get(t, 0) * tf[t] * (self.k1 + 1) / (tf[t] + self.k1 * (1 - self.b + self.b * dl / self.avg))
                for t in q
                if t in tf
            )
            if s > 0:
                scores.append((self.ids[i], s))
        return sorted(scores, key=lambda x: -x[1])[:k]
