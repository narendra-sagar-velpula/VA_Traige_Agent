"""Score triage decisions against analyst ground truth, and export runs for agent-eval-console.

Metrics that matter for VA:
- unsafe dismissals   truly affected findings closed as not affected (must be zero)
- automation rate     findings decided without a human (not needs_review)
- accuracy of automated decisions
- false alarms        not-affected findings reported as affected (wasted analyst time)
"""

from __future__ import annotations

from pathlib import Path

import yaml

from .models import Decision, Finding


def load_truth(path: str | Path) -> dict[str, dict]:
    doc = yaml.safe_load(Path(path).read_text())
    out = {}
    for section in ("sca", "sast"):
        for key, (label, vex, note) in (doc.get(section) or {}).items():
            k = key if key.startswith(f"{section}:") else f"{section}:{key}"
            out[k] = {"label": label, "vex": vex, "note": note}
    return out


def score(findings: dict[str, Finding], decisions: list[Decision], truth: dict[str, dict]) -> dict:
    rows, missing = [], []
    for d in decisions:
        t = truth.get(d.key)
        if t is None:
            missing.append(d.key)
            continue
        rows.append((findings[d.key], d, t["label"]))

    def block(rs):
        n = len(rs)
        auto = [r for r in rs if r[1].status != "needs_review"]
        correct = [r for r in auto if r[1].status == r[2]]
        affected = [r for r in rs if r[2] == "affected"]
        return {
            "findings": n,
            "truly_affected": len(affected),
            "automated": len(auto),
            "automation_rate": len(auto) / n if n else 0.0,
            "automated_accuracy": len(correct) / len(auto) if auto else 0.0,
            "correct": len(correct),
            "needs_review": n - len(auto),
            "unsafe_dismissals": sorted(r[1].key for r in rs if r[2] == "affected" and r[1].status == "not_affected"),
            "false_alarms": sorted(r[1].key for r in rs if r[2] == "not_affected" and r[1].status == "affected"),
            "affected_caught": sum(1 for r in affected if r[1].status in ("affected", "needs_review")),
        }

    return {
        "overall": block(rows),
        "sca": block([r for r in rows if r[0].source == "sca"]),
        "sast": block([r for r in rows if r[0].source == "sast"]),
        "unlabelled": missing,
    }


def export_run(
    name: str,
    system: str,
    findings: dict[str, Finding],
    decisions: list[Decision],
    truth: dict[str, dict],
    traces: dict[str, list[dict]] | None = None,
    latency_ms: dict[str, float] | None = None,
    model: str | None = None,
    git_sha: str | None = None,
) -> dict:
    """agent-eval-console run format.

    A finding passes when its outcome is safe and needs no avoidable human work:
    - truly affected: passes unless it was dismissed (affected or needs_review are both safe)
    - truly not affected: passes only when it was dismissed (needs_review wastes analyst time,
      affected is a false alarm)
    Truly affected findings are tagged `critical`, so the eval gate blocks any change that starts
    dismissing one of them, however much automation it adds elsewhere."""
    results = []
    for d in decisions:
        t = truth.get(d.key)
        if t is None:
            continue
        f = findings[d.key]
        tags = [f"source:{f.source}", f"truth:{t['label']}"]
        if t["label"] == "affected":
            tags.append("critical")  # dismissing a real vulnerability must fail the gate
        if f.kev:
            tags.append("kev")
        results.append(
            {
                "case_id": d.key.replace("@", "/"),
                "trial": 0,
                "passed": (d.status != "not_affected") if t["label"] == "affected" else (d.status == "not_affected"),
                "expected": t["label"],
                "predicted": d.status,
                "latency_ms": (latency_ms or {}).get(d.key),
                "tags": tags,
                "scores": {
                    "automated": d.status != "needs_review",
                    "unsafe_dismissal": t["label"] == "affected" and d.status == "not_affected",
                    "false_alarm": t["label"] == "not_affected" and d.status == "affected",
                },
                "trace": (traces or {}).get(d.key, [])[:200],
            }
        )
    return {
        "run": {
            "name": name,
            "agent": "va-triage-agent",
            "system": system,
            "model": model,
            "git_sha": git_sha,
            "notes": f"{len(results)} findings of netcfg-service 2024.2 vs analyst ground truth",
        },
        "results": results,
    }
