#!/usr/bin/env bash
# Refresh the advisory snapshot (PyPA advisory database, OSV format, CC-BY 4.0) for every package in
# an SBOM, and the CISA Known Exploited Vulnerabilities catalog.
#   scripts/update_data.sh lab/netcfg-service/sbom/netcfg-service.cdx.json
set -euo pipefail
SBOM="${1:?usage: update_data.sh SBOM.cdx.json}"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
git clone --depth 1 -q https://github.com/pypa/advisory-database "$TMP/pypa"
git clone --depth 1 -q https://github.com/cisagov/kev-data "$TMP/kev"
mkdir -p data/advisories
for pkg in $(python3 -c "
import json, re, sys
for c in json.load(open(sys.argv[1]))['components']:
    print(re.sub(r'[-_.]+', '-', c['name']).lower())" "$SBOM"); do
  if [ -d "$TMP/pypa/vulns/$pkg" ]; then rm -rf "data/advisories/$pkg"; cp -r "$TMP/pypa/vulns/$pkg" data/advisories/; fi
done
cp "$TMP/pypa/LICENSE" data/advisories/LICENSE
cp "$TMP/kev/known_exploited_vulnerabilities.json" data/kev.json
git -C "$TMP/pypa" log -1 --format="%H %cs" > data/ADVISORY_DB_COMMIT
echo "advisories: $(cat data/ADVISORY_DB_COMMIT); KEV: $(python3 -c "import json; print(json.load(open('data/kev.json'))['catalogVersion'])")"
